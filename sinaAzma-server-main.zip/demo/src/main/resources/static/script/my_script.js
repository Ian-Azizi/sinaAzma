$("button").click(function(){
    $.getJSON("json_demo.json",function(obj) {
        $.each(obj,function(key,value) {
            $("ul").append("<li>"+value.company_name+"<li>")

          })
    });
})