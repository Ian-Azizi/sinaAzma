var module = angular.module('myApp.controller',['myApp.service']);
module.controller('HomeController',['$scope','HomeService',
  function($scope,HomeService){
    $scope.data = [];

    var onSuccess = function(response){
      $scope.data = response.data;
    };

    var onError = function(error){
      console.log('Error fetching data...');
    };

    function getAllCompany_name(){
      HomeService.getAllCompany_name().then(onSuccess,onError)
    };
  }

]);