package com.example.demo.repositores.project;

import com.example.demo.entites.project.ended_project;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface ended_projectRepository extends PagingAndSortingRepository<ended_project,Long> {
    List<ended_project>findAllById(long id);

}
