package com.example.demo.Service.QC.tech;

import com.example.demo.entites.QC.tech.tech;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.QC.tech.techRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class techService {
@Autowired
    private techRepository repository;
public List<tech>findAllByImage(String image){
    List<tech>list=new ArrayList<>();
    return repository.findAllByImage(image);
}
public tech getById(long id){
    Optional<tech>data=repository.findById(id);
    if (data.isPresent())return getById(id);
    return null;
}
public tech add(tech data){
    return repository.save(data);
}
public tech update(tech data) throws DataNotFoundException {
    tech oldDate = getById(data.getId());
    if (oldDate==null){
        throw new DataNotFoundException("data with id"+data.getId()+"not found");
    }
    oldDate.setImage(data.getImage());
    oldDate.setTitle(data.getTitle());
    oldDate.setDescription(data.getDescription());
    oldDate.setLink(data.getLink());
    return repository.save(data);
}
public boolean deleteById(long id) throws DataNotFoundException {
    tech oldDate = getById(id);
    if (oldDate==null){
        throw new DataNotFoundException("data with id"+id+"not found");
    }
     repository.deleteById(id);
    return true;
}
}
