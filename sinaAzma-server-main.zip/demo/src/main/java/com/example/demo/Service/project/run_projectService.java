package com.example.demo.Service.project;

import com.example.demo.entites.project.run_project;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.project.run_projectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class run_projectService {
@Autowired
    private run_projectRepository repository;
public List<run_project>findAllById(long id){
    List<run_project>list = new ArrayList<>();
    return (List<run_project>) repository.findAllByEnableIsTrueAndId(id);
}
    public run_project getById(long id){
        Optional<run_project> data = repository.findById(id);
        if (data.isPresent())return data.get();
        return null;
    }
public run_project add(run_project data){
    return repository.save(data);
}
public run_project upDate(run_project data) throws DataNotFoundException {
    run_project oldDate = getById (data.getId());
    if (oldDate==null){
        throw new DataNotFoundException("data not found"+data.getId()+"not found");
    }
oldDate.setProject_id(data.getProject_id());
    oldDate.setTitle(data.getTitle());
    oldDate.setDescription(data.getDescription());
    oldDate.setLink(data.getLink());
    oldDate.setImage(data.getImage());
    oldDate.setProject_data(data.getProject_data());
    oldDate.setCustomer(data.getCustomer());
    oldDate.setInspection_Kind(data.getInspection_Kind());
        return repository.save(data);
}
public boolean deleteById(long id) throws DataNotFoundException {
    run_project oldDate = getById(id);
    if (oldDate == null){
        throw new DataNotFoundException("data with id" + id + "not found");
}
repository.deleteById(id);
    return true;
}




}
