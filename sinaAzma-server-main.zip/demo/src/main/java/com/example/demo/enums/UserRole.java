package com.example.demo.enums;

public enum UserRole {
    ADMIN,
    USER,
    MODER,
    Inspection,
    PERSON
}
