package com.example.demo.Controller.api.project_kind;

import com.example.demo.Service.project_kind.generalService;

import com.example.demo.entites.project_kind.general_project;
import com.example.demo.helper.ui.ResponseStatus;
import com.example.demo.helper.ui.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping("/api/general_project")
public class Genral_productController {
    @Autowired
    private generalService service;
    @RequestMapping(value = "/genral/new", produces = "application/json")
    public ServiceResponse<general_project>get(long id){

                general_project get =service.getById(id);
            return  new ServiceResponse<general_project>(ResponseStatus.SUCCESS,get);

    }
        @RequestMapping(value = "/genral/get", produces = "application/json")
        public ServiceResponse<general_project>getCompany_Name(String company_Name){
            return new ServiceResponse<general_project>(ResponseStatus.SUCCESS,new general_project());
        }
    @RequestMapping("/general_project/post")
    public ServiceResponse<general_project>addGeneral_project(@RequestBody general_project Date){
        try{
            general_project adding = service.add(Date);
            return new ServiceResponse<general_project>(ResponseStatus.SUCCESS,adding);
        }catch (Exception e){
            return new ServiceResponse<general_project>(e);
        }
//        return new ServiceResponse<general_project>(ResponseStatus.SUCCESS, Date);
    }
    @RequestMapping("/general_project/put")
    public ServiceResponse<general_project>upDategeneral_project(@RequestBody general_project data){

        general_project updateData = service.upDate(data);
        return new ServiceResponse<general_project>(ResponseStatus.SUCCESS,updateData);

//        return new ServiceResponse<general_project>(ResponseStatus.SUCCESS,data);
    }
    @DeleteMapping("/genral/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
//    @GetMapping("/test/general_project")
//    public general_project test(){
//        return new general_project();
//    }
}
