package com.example.demo.Controller.api.user;

import com.example.demo.Service.user.UserService;
import com.example.demo.config.JwtTokenUtil;
import com.example.demo.entites.user.User;
import com.example.demo.helper.ui.ResponseStatus;
import com.example.demo.helper.ui.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
//@RequestMapping("/api/User")
public class UserController {
    @Autowired
    private UserService service;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @RequestMapping("/user/login")
    public ServiceResponse<User>login(@RequestBody User user){
        List<User> userData = service.auth(user.getUsername(), user.getPassword());
        if (userData == null)
            return new ServiceResponse<User>(ResponseStatus.FAILED, "Incorrect username or password");

        User userVM = new User();

        String token = jwtTokenUtil.generateToken(userVM);
        userVM.setToken(token);
        return new ServiceResponse<User>(ResponseStatus.SUCCESS, userVM);
    }
    @RequestMapping(value = "/test/user", produces = "application/json")
    public ServiceResponse<User> getByUserNameAndPassWord(String username, String password){
        try{
            List<User> get = service.getUserWord(username,password);
            return (ServiceResponse<User>) new ServiceResponse<User>(ResponseStatus.SUCCESS,get);
        }catch (Exception e){
            return new ServiceResponse<User>(e);
        }
    }

    @RequestMapping("/user/post")
    public ServiceResponse<User>addUser(@RequestBody User Date){
        try{
            User adding = service.add(Date);
            User userVM = new User();
            String token = jwtTokenUtil.generateToken(userVM);
            userVM.setToken(token);

            return new ServiceResponse<User>(ResponseStatus.SUCCESS,adding);
        }catch (Exception e){
            return new ServiceResponse<User>(e);
        }
//        return new ServiceResponse<User>(ResponseStatus.SUCCESS, Date);
    }
    @PutMapping("/user/put")
    public ServiceResponse<User>upDateUser(@RequestBody User data){

            User updateData = service.upData(data);
            return new ServiceResponse<User>(ResponseStatus.SUCCESS,updateData);

//        return new ServiceResponse<User>(ResponseStatus.SUCCESS,data);
    }
    @DeleteMapping("/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
//    @GetMapping("/test/user")
//    public User test(){
//        return new User();
//    }
}
