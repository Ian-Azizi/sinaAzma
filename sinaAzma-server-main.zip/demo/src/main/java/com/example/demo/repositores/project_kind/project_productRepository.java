package com.example.demo.repositores.project_kind;

import com.example.demo.entites.project_kind.project_product;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface project_productRepository extends PagingAndSortingRepository<project_product,Long> {
    @Query(value="select * from company_name",nativeQuery=true)
    List<project_product> findAllByCompany_name(String Company_name);
    Optional<project_product> findAllById(long id);
}
