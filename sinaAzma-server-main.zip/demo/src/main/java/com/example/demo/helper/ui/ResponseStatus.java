package com.example.demo.helper.ui;

public enum ResponseStatus {
    SUCCESS,
    FAILED,
    EXCEPTION
}
