package com.example.demo.entites.project_kind;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class general_project {
@GeneratedValue
    @Id
    private long id;
private String title;
private String link;
private String description;
private String image;
private String client;
private String RefNo;
private String POI;
private String ATA;
private String Surveyor;
private String Assistant;
private String DIv;
private String goods;
private String vessel;

private String data;
private String Hours;
private boolean Packing;
private boolean sampling;
private boolean Dispatch_samples;
private boolean Container_check;
private boolean  Weighing;
private boolean Stuffing_supervision;
private boolean After;
private String temperature_recording;
private boolean permanent_sealing;
private boolean Temporary_sealing;
private String loding_supervisie;
private boolean Draft_survey;
private boolean  hold_inspection;
private boolean on_hire_survey;
private boolean Container;
private boolean Tape;
private boolean Documents;
private boolean size;
private boolean other;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getRefNo() {
        return RefNo;
    }

    public void setRefNo(String refNo) {
        RefNo = refNo;
    }

    public String getPOI() {
        return POI;
    }

    public void setPOI(String POI) {
        this.POI = POI;
    }

    public String getATA() {
        return ATA;
    }

    public void setATA(String ATA) {
        this.ATA = ATA;
    }

    public String getSurveyor() {
        return Surveyor;
    }

    public void setSurveyor(String surveyor) {
        Surveyor = surveyor;
    }

    public String getAssistant() {
        return Assistant;
    }

    public void setAssistant(String assistant) {
        Assistant = assistant;
    }

    public String getDIv() {
        return DIv;
    }

    public void setDIv(String DIv) {
        this.DIv = DIv;
    }

    public String getGoods() {
        return goods;
    }

    public void setGoods(String goods) {
        this.goods = goods;
    }

    public String getVessel() {
        return vessel;
    }

    public void setVessel(String vessel) {
        this.vessel = vessel;
    }



    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHours() {
        return Hours;
    }

    public void setHours(String hours) {
        Hours = hours;
    }

    public boolean isPacking() {
        return Packing;
    }

    public void setPacking(boolean packing) {
        Packing = packing;
    }

    public boolean isSampling() {
        return sampling;
    }

    public void setSampling(boolean sampling) {
        this.sampling = sampling;
    }

    public boolean isDispatch_samples() {
        return Dispatch_samples;
    }

    public void setDispatch_samples(boolean dispatch_samples) {
        Dispatch_samples = dispatch_samples;
    }

    public boolean isContainer_check() {
        return Container_check;
    }

    public void setContainer_check(boolean container_check) {
        Container_check = container_check;
    }

    public boolean isWeighing() {
        return Weighing;
    }

    public void setWeighing(boolean weighing) {
        Weighing = weighing;
    }

    public boolean isStuffing_supervision() {
        return Stuffing_supervision;
    }

    public void setStuffing_supervision(boolean stuffing_supervision) {
        Stuffing_supervision = stuffing_supervision;
    }

    public boolean isAfter() {
        return After;
    }

    public void setAfter(boolean after) {
        After = after;
    }

    public String getTemperature_recording() {
        return temperature_recording;
    }

    public void setTemperature_recording(String temperature_recording) {
        this.temperature_recording = temperature_recording;
    }

    public boolean isPermanent_sealing() {
        return permanent_sealing;
    }

    public void setPermanent_sealing(boolean permanent_sealing) {
        this.permanent_sealing = permanent_sealing;
    }

    public boolean isTemporary_sealing() {
        return Temporary_sealing;
    }

    public void setTemporary_sealing(boolean temporary_sealing) {
        Temporary_sealing = temporary_sealing;
    }

    public String getLoding_supervisie() {
        return loding_supervisie;
    }

    public void setLoding_supervisie(String loding_supervisie) {
        this.loding_supervisie = loding_supervisie;
    }

    public boolean isDraft_survey() {
        return Draft_survey;
    }

    public void setDraft_survey(boolean draft_survey) {
        Draft_survey = draft_survey;
    }

    public boolean isHold_inspection() {
        return hold_inspection;
    }

    public void setHold_inspection(boolean hold_inspection) {
        this.hold_inspection = hold_inspection;
    }

    public boolean isOn_hire_survey() {
        return on_hire_survey;
    }

    public void setOn_hire_survey(boolean on_hire_survey) {
        this.on_hire_survey = on_hire_survey;
    }

    public boolean isContainer() {
        return Container;
    }

    public void setContainer(boolean container) {
        Container = container;
    }

    public boolean isTape() {
        return Tape;
    }

    public void setTape(boolean tape) {
        Tape = tape;
    }

    public boolean isDocuments() {
        return Documents;
    }

    public void setDocuments(boolean documents) {
        Documents = documents;
    }

    public boolean isSize() {
        return size;
    }

    public void setSize(boolean size) {
        this.size = size;
    }

    public boolean isOther() {
        return other;
    }

    public void setOther(boolean other) {
        this.other = other;
    }
}
