package com.example.demo.repositores.project;

import com.example.demo.entites.project.run_project;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface run_projectRepository extends PagingAndSortingRepository<run_project,Long> {

List<run_project>findAllByEnableIsTrueAndId(long id);
List<run_project>findAllByCustomer(String customer);

}
