var module = angular.module('myApp.service',[]);
module.service('HomeService',['$http',function($http){
    function doFetchProject_product(){
        var response = $http.get("/employees");
        return response;
    };
    return{
        getAllCompany_name : function(){
            return doFetchEmployees();
        }
    };

}]);