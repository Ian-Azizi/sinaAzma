function validate(){
        alert("با موفقیت درخواست ارسال شد")
        window.location = "run_project.html";
        return false;
    }


