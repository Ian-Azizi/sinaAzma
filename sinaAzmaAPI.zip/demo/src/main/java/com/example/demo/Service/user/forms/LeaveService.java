package com.example.demo.Service.user.forms;

import com.example.demo.entites.user.form.Leave;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.user.forms.leaveRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class LeaveService {
@Autowired
    private leaveRepository repository;
public List<Leave>findAllByName(String name){
    List<Leave>list=new ArrayList<>();
return repository.findAllByName(name);
}
public Leave getById(long id){
        Optional<Leave>data=repository.findById(id);
        if (data.isPresent())return getById(id);
return null;
}
public List<Leave>add(Leave data){
  return (List<Leave>) repository.save(data);
}
public List<Leave>upDate(Leave data) throws DataNotFoundException {
    Leave oldDate = getById(data.getId());
    if (oldDate == null) {
        throw new DataNotFoundException("data not found" + data.getId() + "not found");
    }
    oldDate.setTitle(data.getTitle());
    oldDate.setLink(data.getLink());
    oldDate.setDescription(data.getDescription());
    oldDate.setImage(data.getImage());
    oldDate.setName(data.getName());

return (List<Leave>) repository.save(data);
}
    public boolean deleteById(long id) throws DataNotFoundException {

        Leave oldDate = (Leave) getById(id);
        if (oldDate == null){
            throw new DataNotFoundException("data with id" + id + "not found");
        }
        repository.deleteById(id);
        return true;
    }

}

