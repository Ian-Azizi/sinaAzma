package com.example.demo.Service.user;


import com.example.demo.entites.user.User;
import com.example.demo.helper.exception.DataNotFoundException;

import com.example.demo.helper.util.SecurityUtils;
import com.example.demo.repositores.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository repository;

    @Autowired
    private SecurityUtils securityUtils;
    public User auth(String username,String password){

            try {
                password = securityUtils.encryptSHA1(password);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
            return (User) repository.findFirstByUsernameAndPassword(username, password);

    }
    public List<User>getUserWord(String username,String password){
        List<User>list=new ArrayList<>();
        return (List<User>) repository.findFirstByUsernameAndPassword(username,password);
    }
    public User getById(long id) {
        Optional<User> data = repository.findById(id);
        if (data.isPresent()) return data.get();
        return null;
    }

    public User add(User data){
        return repository.save(data);
    }
    public User upData(User data)  {
        User oldDate = getById(data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
            oldDate.setUsername(data.getUsername());
        oldDate.setPassword(data.getPassword());
        return repository.save(oldDate);

    }
    public boolean deleteById(long id) throws DataNotFoundException {
        User oldDate = getById(id);
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+id+"not found");
        }
        repository.deleteById(id);
        return true;
    }
}
