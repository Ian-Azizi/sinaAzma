package com.example.demo.repositores.project;

import com.example.demo.entites.project.old_project;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface old_projectRepository extends PagingAndSortingRepository<old_project,Long> {
List<old_project>findAllById(long id);
}
