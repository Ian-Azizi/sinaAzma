package com.example.demo.Service.project_kind;

import com.example.demo.entites.project_kind.general_project;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.project_kind.general_projectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class generalService {
@Autowired
    private general_projectRepository repository;
    public List<general_project> findAllByClient(String Client){
        List<general_project>list=new ArrayList<>();
        return repository.findAllByClient(Client);
    }
    public List<general_project>findAllById(long id){
        List<general_project>list=new ArrayList<>();
        return repository.findAllById(id);
    }
    public general_project getById(long id){
        Optional<general_project> data = repository.findById(id);
        if (data.isPresent())return data.get();
        return null;

    }
    public general_project add(general_project data){
        return repository.save(data);
    }
    public general_project upDate(general_project data) throws DataNotFoundException {
        general_project oldDate = getById (data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data not found"+data.getId()+"not found");
        }
            oldDate.setClient(data.getClient());
        oldDate.setATA(data.getATA());
        oldDate.setDescription(data.getDescription());
        oldDate.setLink(data.getLink());
        oldDate.setAssistant(data.getAssistant());
        oldDate.setImage(data.getImage());
        oldDate.setDIv(data.getDIv());
        oldDate.setGoods(data.getGoods());
        oldDate.setHours(data.getHours());

        return repository.save(data);
    }
    public boolean deleteById(long id) throws DataNotFoundException {
        general_project oldDate = getById(id);
        if (oldDate == null){
            throw new DataNotFoundException("data with id" + id + "not found");
        }
        repository.deleteById(id);
        return true;
    }

}
