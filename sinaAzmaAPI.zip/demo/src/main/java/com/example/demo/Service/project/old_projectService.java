package com.example.demo.Service.project;

import com.example.demo.entites.project.old_project;
import com.example.demo.helper.exception.DataNotFoundException;
import com.example.demo.repositores.project.old_projectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class old_projectService {
    @Autowired
    private old_projectRepository repository;
    public List<old_project>findAllById(long id){
        List<old_project>list = new ArrayList<>();
        return (List<old_project>) repository.findAllById(id);
    }
    public old_project getById(long id){
        Optional<old_project> data = repository.findById(id);
        if (data.isPresent())return data.get();
        return null;
    }
    public old_project add(old_project data){
        return repository.save(data);
    }
    public old_project upDate(old_project data) throws DataNotFoundException {
        old_project oldDate = getById (data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data not found"+data.getId()+"not found");
        }
        oldDate.setProject_id(data.getProject_id());
        oldDate.setTitle(data.getTitle());
        oldDate.setDescription(data.getDescription());
        oldDate.setLink(data.getLink());
        oldDate.setImage(data.getImage());
        oldDate.setProject_data(data.getProject_data());
        oldDate.setCustomer(data.getCustomer());
        oldDate.setInspection_Kind(data.getInspection_Kind());
        return repository.save(data);
    }
    public boolean deleteById(long id) throws DataNotFoundException {
        old_project oldDate = getById(id);
        if (oldDate == null){
            throw new DataNotFoundException("data with id" + id + "not found");
        }
        repository.deleteById(id);
        return true;
    }




}
