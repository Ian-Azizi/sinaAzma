package com.example.demo.repositores.project_kind;

import com.example.demo.entites.project_kind.general_project;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface general_projectRepository extends PagingAndSortingRepository<general_project,Long> {
    List<general_project>findAllByClient(String Client);
    List<general_project>findAllById(long id);

}
