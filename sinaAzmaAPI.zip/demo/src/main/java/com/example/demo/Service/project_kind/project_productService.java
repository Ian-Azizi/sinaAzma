package com.example.demo.Service.project_kind;
import com.example.demo.entites.project_kind.project_product;
import com.example.demo.helper.exception.DataNotFoundException;

import com.example.demo.helper.util.SecurityUtils;

import com.example.demo.repositores.project_kind.project_productRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class project_productService {
    @Autowired
    private project_productRepository repository;



    public List<project_product>GetCompanyName(String CompanyName){
        List<project_product>list=new ArrayList<>();
        return (List<project_product>) repository.findAllByCompany_name(CompanyName);
    }
    public project_product getById(long id) {
        Optional<project_product> data = repository.findById(id);
        if (data.isPresent()) return data.get();
        return null;
    }

    public project_product add(project_product data){
        return repository.save(data);
    }
    public project_product upData(project_product data)  {
        project_product oldDate = getById(data.getId());
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+data.getId()+"not found");
        }
            oldDate.setProject_Register(data.getProject_Register());
            oldDate.setProduct_Certification(data.isProduct_Certification());
            oldDate.setProject_num(data.getProject_num());
            oldDate.setFex(data.getFex());
            oldDate.setOther_Certification(data.getOther_Certification());
            oldDate.setTel_phone(data.getTel_phone());
            oldDate.setEmail(data.getEmail());
            oldDate.setNamouna_bardari(data.isNamouna_bardari());
            oldDate.setNational_ID(data.getNational_ID());
            oldDate.setCompany_name(data.getCompany_name());

        return repository.save(oldDate);

    }
    public boolean deleteById(long id) throws DataNotFoundException {
        project_product oldDate = getById(id);
        if (oldDate==null){
            throw new DataNotFoundException("data with id"+id+"not found");
        }
        repository.deleteById(id);
        return true;
    }
}
