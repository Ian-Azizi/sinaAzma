package com.example.demo.helper.exception;

public class DataNotFoundException extends RuntimeException  {
    public DataNotFoundException (String message){
        super(message);
    }

  public  DataNotFoundException(Long id) {
        super("Could not find employee " + id);
    }


}
