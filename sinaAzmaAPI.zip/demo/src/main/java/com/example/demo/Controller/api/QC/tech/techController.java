//package com.example.demo.Controller.api.QC.tech;
//
//import com.example.demo.Service.QC.tech.techService;
//import com.example.demo.entites.QC.tech.tech;
//import com.example.demo.entites.project_kind.project_product;
//import com.example.demo.helper.exception.DataNotFoundException;
//import com.example.demo.helper.ui.ResponseStatus;
//import com.example.demo.helper.ui.ServiceResponse;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@Controller
//@RestController("/api/techController")
//public class techController {
//    @Autowired
//    private techService service;
//    @GetMapping("/tech")
//    public ServiceResponse<tech>get(String image){
//        try{
//            List<tech>result = service.findAllByImage(image);
//            return new ServiceResponse<tech>(result, ResponseStatus.SUCCESS);
//        }catch (Exception e){
//            return new ServiceResponse<tech>(e);
//        }
//    }
//    @PostMapping("/tech")
//    public ServiceResponse<tech>add(@PathVariable tech data){
//        try{
//            List<tech>result = (List<tech>) service.add(data);
//            return new ServiceResponse<tech>(result,ResponseStatus.SUCCESS);
//        }catch (Exception e){
//            return new ServiceResponse<tech>(e);
//        }
//    }
//    @PutMapping("/tech")
//    public ServiceResponse<tech>upDate(@PathVariable tech data) throws DataNotFoundException {
//        try{
//            List<tech>result = (List<tech>) service.update(data);
//            return new ServiceResponse<tech>(result,ResponseStatus.SUCCESS);
//        }catch (Exception e){
//            return new ServiceResponse<tech>(e);
//        }
//    }
//    @DeleteMapping("/tech")
//    public ServiceResponse<tech>delete(long id){
//        try{
//            boolean result = service.deleteById(id);
//            return new ServiceResponse<tech>(result,ResponseStatus.SUCCESS);
//        }catch (Exception e){
//            return new ServiceResponse<tech>(e);
//
//        }
//    }
//}
