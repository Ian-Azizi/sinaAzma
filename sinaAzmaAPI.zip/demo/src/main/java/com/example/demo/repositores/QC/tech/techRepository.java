package com.example.demo.repositores.QC.tech;

import com.example.demo.entites.QC.tech.tech;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface techRepository extends PagingAndSortingRepository<tech,Long> {
    List<tech>findAllByImage(String search);

}
