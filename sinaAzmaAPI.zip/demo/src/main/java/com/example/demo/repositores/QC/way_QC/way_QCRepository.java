package com.example.demo.repositores.QC.way_QC;

import com.example.demo.entites.QC.way_QC.way_QC;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface way_QCRepository extends PagingAndSortingRepository<way_QC,Long> {
List<way_QC>findAllByImage(String search);

}
