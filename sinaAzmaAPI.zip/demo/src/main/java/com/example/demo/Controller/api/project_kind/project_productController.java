package com.example.demo.Controller.api.project_kind;

import com.example.demo.Service.project_kind.project_productService;

import com.example.demo.entites.project_kind.project_product;
import com.example.demo.helper.ui.ResponseStatus;
import com.example.demo.helper.ui.ServiceResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
//@RequestMapping("/api/Project_product")
public class project_productController {
    @Autowired
    private project_productService service;
    @RequestMapping(value = "/new", produces = "application/json")
    public ServiceResponse<project_product>get(long id){

                project_product get =service.getById(id);
            return  new ServiceResponse<project_product>(ResponseStatus.SUCCESS,get);

    }
        @RequestMapping(value = "/company_name", produces = "application/json")
        public ServiceResponse<project_product>getCompany_Name(String company_Name){
            return new ServiceResponse<project_product>(ResponseStatus.SUCCESS,new project_product());
        }
    @RequestMapping("/Project_product/post")
    public ServiceResponse<project_product>addProject_product(@RequestBody project_product Date){
        try{
            project_product adding = service.add(Date);
            return new ServiceResponse<project_product>(ResponseStatus.SUCCESS,adding);
        }catch (Exception e){
            return new ServiceResponse<project_product>(e);
        }
//        return new ServiceResponse<Project_product>(ResponseStatus.SUCCESS, Date);
    }
    @PutMapping("/Project_product/put")
    public ServiceResponse<project_product>upDateProject_product(@RequestBody project_product data){

        project_product updateData = service.upData(data);
        return new ServiceResponse<project_product>(ResponseStatus.SUCCESS,updateData);

//        return new ServiceResponse<Project_product>(ResponseStatus.SUCCESS,data);
    }
    @DeleteMapping("/project/{id}")
    public ServiceResponse<Boolean> delete(@PathVariable long id) {
        try {
            boolean result = service.deleteById(id);
            return new ServiceResponse<Boolean>(ResponseStatus.SUCCESS, result);
        } catch (Exception e) {
            return new ServiceResponse<Boolean>(e);
        }
    }
//    @GetMapping("/test/Project_product")
//    public project_product test(){
//        return new project_product();
//    }
}
